setwd("~/Desktop/PRSLDPrep2")

##################################################
#                                                #
#                  LDPred2                       #
#                                                #
##################################################

library(bigsnpr)
options(bigstatsr.check.parallel.blas = FALSE)
options(default.nproc.blas = NULL)
library(data.table)
library(magrittr)

phenotype <- fread("ADNI.pheno")
covariate <- fread("ADNI.cov")
pcs <- fread("ADNI.eigenvec")
# rename columns
pcs <- pcs[,c(-9,-10,-11)]
colnames(pcs) <- c("FID","IID", paste0("PC",1:6))
# generate required table
pheno <- merge(phenotype, covariate,by=c("FID","IID","Sex"))
pheno <- merge(pheno, pcs,by=c("FID","IID"))

if(file.exists("map_hm3_ldpred2.rds")){ load("map_hm3_ldpred2.rds")} else {info <- readRDS(runonce::download_file(
  "https://ndownloader.figshare.com/files/25503788",
  fname = "map_hm3_ldpred2.rds")); save(info,file="map_hm3_ldpred2.rds")}

################################################################### 
#        Read in the summary statistic file
###################################################################

# Set subfolder as new temporary working directory
setwd("~/Desktop/PRSLDPrep2/34PRSADNIBMI")

sumstats_K <- bigreadr::fread2("GIANT_BMI_Speliotes2010_publicrelease_HapMapCeuFreq.txt.gz")
head(sumstats_K)# LDpred 2 require the header to follow the exact naming

#names(sumstats_D)[c(1,2,5,6,7,8,10)]=c("rsid","chr","pos","a0","a1","beta","p")
#sumstats_K$beta <- log(sumstats_K$OR)
sumstats_K<-sumstats_K[c(1,3,2,5,7,6)]
colnames(sumstats_K)=c("rsid","a0","a1","beta","p","SE")

sumstats_K$a1=toupper(sumstats_K$a1)
sumstats_K$a0=toupper(sumstats_K$a0)

#n_eff<-4/(1/cases + 1/controls)
n_eff=16068
sumstats_K$n_eff=rep(n_eff,length(rownames(sumstats_K))) #number of sample in Kunkle Summary Statistic

head(sumstats_K)

x<-intersect(sumstats_K$rsid,info$rsid)

sumstats1_K <- sumstats_K[sumstats_K$rsid %in% x,]
dim(info)
info <- info[info$rsid %in% x,]
dim(info)

info<-info[order(info$rsid),]	
sumstats1_K <- sumstats1_K[order(sumstats1_K$rsid),]

identical(sumstats1_K$rsid,info$rsid)
head(sumstats1_K)
head(info)


sumstats1_K$chr=info$chr
sumstats1_K$pos=info$pos
head(sumstats1_K)


NCORES <- nb_cores()
# Open a temporary file
tmp <- tempfile(tmpdir = "tmp-data")
on.exit(file.remove(paste0(tmp, ".sbk")), add = TRUE)
# Initialize variables for storing the LD score and LD matrix
corr <- NULL
ld <- NULL
# We want to know the ordering of samples in the bed file 
fam.order <- NULL
# preprocess the bed file (only need to do once for each data set)

setwd("~/Desktop/PRSLDPrep2")

snp_readBed("ADNI.bed")
# now attach the genotype object
obj.bigSNP <- snp_attach("ADNI.rds")
# extract the SNP information from the genotype
map <- obj.bigSNP$map[-3]
names(map) <- c("chr", "snp", "pos", "a1", "a0")

#index_D= sumstats1_D$MarkerName %in% map[,"MarkerName"]
#table(index_D)
#index_K= sumstats1_K$MarkerName %in% map[,"MarkerName"]
#table(index_K)

#info_snp_D <- snp_match(sumstats1_D, map)
#info_snp_K <- snp_match(sumstats1_K, map)
#sumstats1_D= sumstats1_D[sumstats1_D$MarkerName %in% map[,"MarkerName"],]
#info_snp <- snp_match(sumstats_K, map)
info_snp <- snp_match(sumstats1_K, map)
# Assign the genotype to a variable for easier downstream analysis
genotype <- obj.bigSNP$genotypes
# Rename the data structures
CHR <- map$chr
POS <- map$pos
# get the CM information from 1000 Genome
# will download the 1000G file to the current directory (".")
POS2 <- snp_asGeneticPos(CHR, POS, dir = ".")
# Error in { : task 1 failed - "cannot open URL
# 'https://github.com/joepickrell/1000-genomes-genetic-maps/raw/master/interpolated_OMNI/chr2.OMNI.interpolated_genetic_map.gz'"
# Solution: Manual download via link above

################################################################### 
#        calculate LD
###################################################################
# 
for (chr in 1:22) {
  # Extract SNPs that are included in the chromosome
  ind.chr <- which(info_snp$chr == chr)
  ind.chr2 <- info_snp$`_NUM_ID_`[ind.chr]
  # Calculate the LD
  corr0 <- snp_cor(
    genotype,
    ind.col = ind.chr2,
    ncores = NCORES,
    infos.pos = POS2[ind.chr2],
    size = 3 / 1000
  )
  if (chr == 1) {
    ld <- Matrix::colSums(corr0^2)
    corr <- as_SFBM(corr0, tmp)
  } else {
    ld <- c(ld, Matrix::colSums(corr0^2))
    corr$add_columns(corr0, nrow(corr))
  }
}

fam.order <- as.data.table(obj.bigSNP$fam)
# Rename fam order
setnames(fam.order,
         c("family.ID", "sample.ID"),
         c("FID", "IID"))

######################################################
#      Perform LD score regression
######################################################

df_beta <- info_snp[,c("beta", "SE", "_NUM_ID_","n_eff")]
names(df_beta)[2]="beta_se"

ldsc <- snp_ldsc(   ld, 
                    length(ld), 
                    chi2 = (df_beta$beta / df_beta$beta_se)^2,
                    sample_size = df_beta$n_eff, 
                    blocks = NULL)

h2_est <- ldsc[["h2"]]

#####################################################################
#                 Obtain LDpred adjusted beta
######################################################################
#### infinitesimal model
beta_inf <- snp_ldpred2_inf(corr, df_beta, h2 = h2_est)

################################################################### 
#        Obtain model PRS
###################################################################

#### infinitesimal model
if(is.null(obj.bigSNP)){
  obj.bigSNP <- snp_attach("EUR.QC.rds")
}
genotype <- obj.bigSNP$genotypes
# calculate PRS for all samples
ind.test <- 1:nrow(genotype)
pred_inf <- big_prodVec(    genotype,
                            beta_inf,
                            ind.row = ind.test,
                            ind.col = info_snp$`_NUM_ID_`)

pheno_PRS<-read.csv("Pheno_ADNI_PRS.csv")

PRS_ExtremeBMI<-pred_inf

pheno_PRS<-cbind(pheno_PRS, PRS_ExtremeBMI)
pheno_PRS_table<-data.frame()

boxplot(pheno_PRS$PRS_ExtremeBMI~pheno_PRS$three)

#trait-/disease-specific dataframes by classes, leaving out NAs
dataframe_ExtremeBMI <- cbind(pheno_PRS$three_class, PRS_ExtremeBMI)

indices_stable <- which(dataframe_ExtremeBMI == "stable")
pheno_PRS_stable <- dataframe_ExtremeBMI[indices_stable, ]
median_stable <- median(as.numeric(pheno_PRS_stable[,2]))
mean_stable <- mean(as.numeric(pheno_PRS_stable[,2]))

indices_slowDecline <- which(dataframe_ExtremeBMI == "slowDecline")
pheno_PRS_slowDecline <- dataframe_ExtremeBMI[indices_slowDecline, ]
median_slowDecline <- median(as.numeric(pheno_PRS_slowDecline[,2]))
mean_slowDecline <- mean(as.numeric(pheno_PRS_slowDecline[,2]))

indices_rapidDecline <- which(dataframe_ExtremeBMI == "rapidDecline")
pheno_PRS_rapidDecline <- dataframe_ExtremeBMI[indices_rapidDecline, ]
median_rapidDecline <- median(as.numeric(pheno_PRS_rapidDecline[,2]))
mean_rapidDecline <- mean(as.numeric(pheno_PRS_rapidDecline[,2]))

pheno_PRS_summary <- rbind(median_stable, mean_stable, median_slowDecline, mean_slowDecline, median_rapidDecline, mean_rapidDecline)
colnames(pheno_PRS_summary)[1]<- "35PRSADNIExtremeBMI"

write.csv(pheno_PRS, "Pheno_ADNI_PRS.csv")
write.csv(pheno_PRS_summary, "Pheno_ADNI_PRS_summary_EBMI.csv")