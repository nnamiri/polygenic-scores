
##################################################
#                                                #
#               QC of Base Data                  #
#                                                #
##################################################
### remove duplicated SNPs
#gunzip -c Derojas_SummaryStats.txt.gz |\
#awk '{seen[$1]++; if(seen[$1]==1){ print}}' |\
#gzip - > Derojas_SummaryStats.nodup.gz

###Ambiguous SNPs

#gunzip -c Derojas_SummaryStats.nodup.gz |\
#awk '!( ($4=="A" && $5=="T") || \
#($4=="T" && $5=="A") || \
#($4=="G" && $5=="C") || \
#($4=="C" && $5=="G")) {print}' |\
#gzip > Kunkle_SummaryStats.QC.gz

##################################################
#                                                #
#               QC of Target data                #
#                                                #
##################################################
#

#~/plink \
#--bfile ADNI \
#--maf 0.01 \
#--hwe 1e-6 \
#--geno 0.01 \
#--mind 0.01 \
#--write-snplist \
#--make-just-fam \
#--out ADNI.QC


#~/plink \
#--bfile ADNI \
#--keep ADNI.QC.fam \
#--extract ADNI.QC.snplist \
#--indep-pairwise 200 50 0.25 \
#--out ADNI.QC

#~/plink \
#--bfile ADNI \
#--extract ADNI.QC.prune.in \
#--keep ADNI.QC.fam \
#--het \
#--out ADNI.QC


dat <- read.table("ADNI.QC.het", header=T) # Read in the EUR.het file, specify it has header
m <- mean(dat$F) # Calculate the mean  
s <- sd(dat$F) # Calculate the SD
valid <- subset(dat, F <= m+3*s & F >= m-3*s) # Get any samples with F coefficient within 3 SD of the population mean
write.table(valid[,c(1,2)], "ADNI.valid.sample", quote=F, row.names=F) # print FID and IID for valid samples
q() # exit R

# Read in bim file
bim <- read.table("ADNI.bim")
colnames(bim) <- c("CHR", "SNP", "CM", "BP", "B.A1", "B.A2")
# Read in QCed SNPs
qc <- read.table("ADNI.QC.snplist", header = F, stringsAsFactors = F)
# Read in the GWAS data
sumstats <-
  read.table(gzfile("Kunkle_SummaryStats.QC.gz"),
             header = T,
             stringsAsFactors = F, 
             sep=' ')
# Change all alleles to upper case for easy comparison
sumstats$A1 <- toupper(sumstats$A1)
sumstats$A2 <- toupper(sumstats$A2)
bim$B.A1 <- toupper(bim$B.A1)
bim$B.A2 <- toupper(bim$B.A2)
# Merge summary statistic with target
names(sumstats)=c("RS","CHR","SNP","SNP1","BP","A1","A2","Beta","SE","P","OR","OR95CI","Direction")
info <- merge(bim, sumstats, by = c("SNP", "CHR", "BP"))
# Filter QCed SNPs
info <- info[info$SNP %in% qc$V1,]
# Function for finding the complementary allele
complement <- function(x) {
  switch (
    x,
    "A" = "T",
    "C" = "G",
    "T" = "A",
    "G" = "C",
    return(NA)
  )
}
# Get SNPs that have the same alleles across base and target
info.match <- subset(info, A1 == B.A1 & A2 == B.A2)
# Identify SNPs that are complementary between base and target
info$C.A1 <- sapply(info$B.A1, complement)
info$C.A2 <- sapply(info$B.A2, complement)
info.complement <- subset(info, A1 == C.A1 & A2 == C.A2)
# Update the complementary alleles in the bim file
# This allow us to match the allele in subsequent analysis
complement.snps <- bim$SNP %in% info.complement$SNP
bim[complement.snps,]$B.A1 <-
  sapply(bim[complement.snps,]$B.A1, complement)
bim[complement.snps,]$B.A2 <-
  sapply(bim[complement.snps,]$B.A2, complement)

# identify SNPs that need recoding
info.recode <- subset(info, A1 == B.A2 & A2 == B.A1)
# Update the recode SNPs
recode.snps <- bim$SNP %in% info.recode$SNP
tmp <- bim[recode.snps,]$B.A1
bim[recode.snps,]$B.A1 <- bim[recode.snps,]$B.A2
bim[recode.snps,]$B.A2 <- tmp

# identify SNPs that need recoding & complement
info.crecode <- subset(info, A1 == C.A2 & A2 == C.A1)
# Update the recode + strand flip SNPs
com.snps <- bim$SNP %in% info.crecode$SNP
tmp <- bim[com.snps,]$B.A1
bim[com.snps,]$B.A1 <- as.character(sapply(bim[com.snps,]$B.A2, complement))
bim[com.snps,]$B.A2 <- as.character(sapply(tmp, complement))

# Output updated bim file
write.table(
  bim[,c("SNP", "B.A1")],
  "ADNI.a1",
  quote = F,
  row.names = F,
  col.names = F,
  sep="\t"
)

mismatch <-
  bim$SNP[!(bim$SNP %in% info.match$SNP |
              bim$SNP %in% info.complement$SNP | 
              bim$SNP %in% info.recode$SNP |
              bim$SNP %in% info.crecode$SNP)]
write.table(
  mismatch,
  "ADNI.mismatch",
  quote = F,
  row.names = F,
  col.names = F
)
q() # exit R

~/plink \
--bfile ADNI \
--extract ADNI.QC.prune.in \
--keep ADNI.valid.sample \
--rel-cutoff 0.125 \
--out ADNI.QC

~/plink \
--bfile ADNI \
--make-bed \
--keep ADNI.QC.rel.id \
--out ADNI.QC \
--extract ADNI.QC.snplist \
--exclude ADNI.mismatch \
--a1-allele ADNI.a1

##################################################
#                                                #
#                  LDPred2                       #
#                                                #
##################################################
#
setwd("~/Desktop/PRSLDPrep2")
library(bigsnpr)
options(bigstatsr.check.parallel.blas = FALSE)
options(default.nproc.blas = NULL)
library(data.table)
library(magrittr)

library(data.table)
library(magrittr)
phenotype <- fread("ADNI.pheno")
covariate <- fread("ADNI.cov")
pcs <- fread("ADNI.eigenvec")
# rename columns
pcs <- pcs[,c(-9,-10,-11)]
colnames(pcs) <- c("FID","IID", paste0("PC",1:6))
# generate required table
pheno <- merge(phenotype, covariate,by=c("FID","IID","Sex"))
pheno <- merge(pheno, pcs,by=c("FID","IID"))

if(file.exists("map_hm3_ldpred2.rds")){ load("map_hm3_ldpred2.rds")} else {info <- readRDS(runonce::download_file(
  "https://ndownloader.figshare.com/files/25503788",
  fname = "map_hm3_ldpred2.rds")); save(info,file="map_hm3_ldpred2.rds")}

################################################################### 
#        Read in the summary statistic file
###################################################################

# Set subfolder as new temporary working directory
setwd("~/Desktop/PRSLDPrep2/69PRSADNIMDD")

sumstats_K <- bigreadr::fread2("PGC_UKB_depression_genome-wide.txt") 
head(sumstats_K)# LDpred 2 require the header to follow the exact naming

#names(sumstats_D)[c(1,2,5,6,7,8,10)]=c("rsid","chr","pos","a0","a1","beta","p")
sumstats_K<-sumstats_K[c(1,3,2,5,7,6)]
colnames(sumstats_K)=c("rsid","a0","a1","beta","p","SE")

sumstats_K$a1=toupper(sumstats_K$a1)
sumstats_K$a0=toupper(sumstats_K$a0)

#n_eff<-4/(1/cases + 1/controls)
n_eff<-4/(1/9240+ 1/9519)
sumstats_K$n_eff=rep(n_eff,length(rownames(sumstats_K))) #number of sample in Kunkle Summary Statistic

head(sumstats_K)

x<-intersect(sumstats_K$rsid,info$rsid)


sumstats1_K <- sumstats_K[sumstats_K$rsid %in% x,]
dim(info)
info <- info[info$rsid %in% x,]
dim(info)

info<-info[order(info$rsid),]	
sumstats1_K <- sumstats1_K[order(sumstats1_K$rsid),]

identical(sumstats1_K$rsid,info$rsid)
head(sumstats1_K)
head(info)


sumstats1_K$chr=info$chr
sumstats1_K$pos=info$pos
head(sumstats1_K)


NCORES <- nb_cores()
# Open a temporary file
tmp <- tempfile(tmpdir = "tmp-data")
on.exit(file.remove(paste0(tmp, ".sbk")), add = TRUE)
# Initialize variables for storing the LD score and LD matrix
corr <- NULL
ld <- NULL
# We want to know the ordering of samples in the bed file 
fam.order <- NULL

setwd("~/Desktop/PRSLDPrep2")

# preprocess the bed file (only need to do once for each data set)
snp_readBed("ADNI.bed")
# now attach the genotype object
obj.bigSNP <- snp_attach("ADNI.rds")
# extract the SNP information from the genotype
map <- obj.bigSNP$map[-3]
names(map) <- c("chr", "snp", "pos", "a1", "a0")

#index_D= sumstats1_D$MarkerName %in% map[,"MarkerName"]
#table(index_D)
#index_K= sumstats1_K$MarkerName %in% map[,"MarkerName"]
#table(index_K)

#info_snp_D <- snp_match(sumstats1_D, map)
#info_snp_K <- snp_match(sumstats1_K, map)
#sumstats1_D= sumstats1_D[sumstats1_D$MarkerName %in% map[,"MarkerName"],]
#info_snp <- snp_match(sumstats_K, map)
info_snp <- snp_match(sumstats1_K, map)
#0 ambiguous SNPs have been removed.
#940,579 variants have been matched; 35 were flipped and 449,418 were reversed.

#new:
#1,029,973 variants to be matched. 0 ambiguous SNPs have been removed.
#940,579 variants have been matched; 35 were flipped and 449,418 were reversed.

# Assign the genotype to a variable for easier downstream analysis
genotype <- obj.bigSNP$genotypes
# Rename the data structures
CHR <- map$chr
POS <- map$pos
# get the CM information from 1000 Genome
# will download the 1000G file to the current directory (".")
POS2 <- snp_asGeneticPos(CHR, POS, dir = ".")
# Error in { : task 1 failed - "cannot open URL
# 'https://github.com/joepickrell/1000-genomes-genetic-maps/raw/master/interpolated_OMNI/chr2.OMNI.interpolated_genetic_map.gz'"
# Solution: Manual download via link above

################################################################### 
#        calculate LD
###################################################################
# 
for (chr in 1:22) {
  # Extract SNPs that are included in the chromosome
  ind.chr <- which(info_snp$chr == chr)
  ind.chr2 <- info_snp$`_NUM_ID_`[ind.chr]
  # Calculate the LD
  corr0 <- snp_cor(
    genotype,
    ind.col = ind.chr2,
    ncores = NCORES,
    infos.pos = POS2[ind.chr2],
    size = 3 / 1000
  )
  if (chr == 1) {
    ld <- Matrix::colSums(corr0^2)
    corr <- as_SFBM(corr0, tmp)
  } else {
    ld <- c(ld, Matrix::colSums(corr0^2))
    corr$add_columns(corr0, nrow(corr))
  }
}

fam.order <- as.data.table(obj.bigSNP$fam)
# Rename fam order
setnames(fam.order,
         c("family.ID", "sample.ID"),
         c("FID", "IID"))

######################################################
#      Perform LD score regression
######################################################

df_beta <- info_snp[,c("beta", "SE", "_NUM_ID_","n_eff")]
names(df_beta)[2]="beta_se"

ldsc <- snp_ldsc(   ld, 
                    length(ld), 
                    chi2 = (df_beta$beta / df_beta$beta_se)^2,
                    sample_size = df_beta$n_eff, 
                    blocks = NULL)

h2_est <- ldsc[["h2"]]

#####################################################################
#                 Obtain LDpred adjusted beta
######################################################################
#### infinitesimal model
beta_inf <- snp_ldpred2_inf(corr, df_beta, h2 = h2_est)

################################################################### 
#        Obtain model PRS
###################################################################

#### infinitesimal model
if(is.null(obj.bigSNP)){
  obj.bigSNP <- snp_attach("EUR.QC.rds")
}
genotype <- obj.bigSNP$genotypes
# calculate PRS for all samples
ind.test <- 1:nrow(genotype)
pred_inf <- big_prodVec(    genotype,
                            beta_inf,
                            ind.row = ind.test,
                            ind.col = info_snp$`_NUM_ID_`)

pheno_PRS<-read.csv("Pheno_ADNI_PRS.csv")				

PRS_MDD<-pred_inf
pheno_PRS<-cbind(pheno_PRS, PRS_MDD)
#

boxplot(pheno_PRS$PRS_MDD~pheno_PRS$three)	

#trait-/disease-specific dataframes by classes, leaving out NAs
dataframe_MDD <- cbind(pheno_PRS$three_class, PRS_MDD)

indices_stable <- which(dataframe_MDD == "stable")
pheno_PRS_stable <- dataframe_MDD[indices_stable, ]
median_stable <- median(as.numeric(pheno_PRS_stable[,2]))
mean_stable <- mean(as.numeric(pheno_PRS_stable[,2]))

indices_slowDecline <- which(dataframe_MDD == "slowDecline")
pheno_PRS_slowDecline <- dataframe_MDD[indices_slowDecline, ]
median_slowDecline <- median(as.numeric(pheno_PRS_slowDecline[,2]))
mean_slowDecline <- mean(as.numeric(pheno_PRS_slowDecline[,2]))

indices_rapidDecline <- which(dataframe_MDD == "rapidDecline")
pheno_PRS_rapidDecline <- dataframe_MDD[indices_rapidDecline, ]
median_rapidDecline <- median(as.numeric(pheno_PRS_rapidDecline[,2]))
mean_rapidDecline <- mean(as.numeric(pheno_PRS_rapidDecline[,2]))

pheno_PRS_summary <- rbind(median_stable, mean_stable, median_slowDecline, mean_slowDecline, median_rapidDecline, mean_rapidDecline)
colnames(pheno_PRS_summary)[1]<- "69PRSADNIMDD"

write.csv(pheno_PRS, "Pheno_ADNI_PRS.csv")
write.csv(pheno_PRS_summary, "Pheno_ADNI_PRS_summary_MDD.csv")			
